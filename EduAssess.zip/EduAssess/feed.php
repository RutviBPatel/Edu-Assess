<?php
include_once 'dbConnection.php';

$ref = @$_GET['q'];
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$id = uniqid();
date_default_timezone_set('Asia/Kolkata');
$date = date("Y-m-d");
$time = date("h:i:sa");
$feedback = $_POST['feedback'];

// Check if the email already exists in the feedback table
$email_check_query = "SELECT email FROM feedback WHERE email='$email'";
$result = mysqli_query($con, $email_check_query);

if (mysqli_num_rows($result) > 0) {
    // Email already exists, so the user can't give feedback again
    header("location:$ref?q=You can give feedback only once time.");
} else {
    // Email does not exist, insert the new feedback
    $q = mysqli_query($con, "INSERT INTO feedback (id, name, email, subject, feedback, date, time) VALUES ('$id', '$name', '$email', '$subject', '$feedback', '$date', '$time')")
        or die("Error in inserting feedback");

    header("location:$ref?q=Thank you for your valuable feedback");
}
