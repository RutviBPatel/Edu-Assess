-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2024 at 12:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eduassess`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role` varchar(10) DEFAULT 'admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `email`, `password`, `role`) VALUES
(NULL, 'admin123@gmail.com', 'admin123', 'head'),
('Teacher1', 'teacher1@gmail.com', 'teacher1', 'admin'),
('Teacher2', 'teacher2@gmail.com', 'teacher2', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('67610d29ec222', '67610d2a01a0a'),
('67610d2a044a7', '67610d2a048e6'),
('67610d2a05ec6', '67610d2a068ef'),
('67610d2a08612', '67610d2a08abf'),
('67610d2a0a494', '67610d2a0ab2f'),
('67610dc82c6b5', '67610dc835f60'),
('67610dc837edc', '67610dc8382ac'),
('67610dc83a0ef', '67610dc83a45c'),
('67610dc83b643', '67610dc83ba76'),
('67610dc83d97d', '67610dc83ddeb'),
('67610ee6b4590', '67610ee6b4bf9'),
('67610ee6b60f5', '67610ee6b6a31'),
('67610ee6b89f6', '67610ee6b8e5c'),
('67610ee6baa3c', '67610ee6badb4'),
('67610f50bcf02', '67610f50c6bb8'),
('67610f50c8d4d', '67610f50c92cd'),
('67610f50cd3c4', '67610f50ce220'),
('67610f50d0845', '67610f50d12be'),
('67610f50d2b48', '67610f50d2fef'),
('67610f50d4eff', '67610f50d530a');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `feedback` varchar(150) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(30) NOT NULL,
  `eid` text NOT NULL,
  `score` int(10) NOT NULL,
  `level` int(10) NOT NULL,
  `right` int(10) NOT NULL,
  `wrong` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `right`, `wrong`, `date`) VALUES
('utsav123@gmail.com', '67610f1aa4f41', 16, 6, 4, 2, '2024-12-17 05:53:08'),
('utsav123@gmail.com', '67610d822fc98', 9, 5, 3, 2, '2024-12-17 06:21:08');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('67610d29ec222', 'A', '67610d2a01a0a'),
('67610d29ec222', 'B', '67610d2a01a12'),
('67610d29ec222', 'C', '67610d2a01a13'),
('67610d29ec222', 'D', '67610d2a01a14'),
('67610d2a044a7', 'A', '67610d2a048e4'),
('67610d2a044a7', 'B', '67610d2a048e6'),
('67610d2a044a7', 'C', '67610d2a048e7'),
('67610d2a044a7', 'D', '67610d2a048e8'),
('67610d2a05ec6', 'A', '67610d2a068eb'),
('67610d2a05ec6', 'B', '67610d2a068ee'),
('67610d2a05ec6', 'C', '67610d2a068ef'),
('67610d2a05ec6', 'D', '67610d2a068f0'),
('67610d2a08612', 'A', '67610d2a08ab9'),
('67610d2a08612', 'B', '67610d2a08abd'),
('67610d2a08612', 'C', '67610d2a08abe'),
('67610d2a08612', 'D', '67610d2a08abf'),
('67610d2a0a494', 'A', '67610d2a0ab2f'),
('67610d2a0a494', 'B', '67610d2a0ab37'),
('67610d2a0a494', 'C', '67610d2a0ab38'),
('67610d2a0a494', 'D', '67610d2a0ab39'),
('67610dc82c6b5', 'A', '67610dc835f60'),
('67610dc82c6b5', 'B', '67610dc835f65'),
('67610dc82c6b5', 'C', '67610dc835f66'),
('67610dc82c6b5', 'D', '67610dc835f67'),
('67610dc837edc', 'A', '67610dc8382a9'),
('67610dc837edc', 'B', '67610dc8382ac'),
('67610dc837edc', 'C', '67610dc8382ad'),
('67610dc837edc', 'D', '67610dc8382ae'),
('67610dc83a0ef', 'A', '67610dc83a458'),
('67610dc83a0ef', 'B', '67610dc83a45b'),
('67610dc83a0ef', 'C', '67610dc83a45c'),
('67610dc83a0ef', 'D', '67610dc83a45d'),
('67610dc83b643', 'A', '67610dc83ba71'),
('67610dc83b643', 'B', '67610dc83ba74'),
('67610dc83b643', 'C', '67610dc83ba75'),
('67610dc83b643', 'D', '67610dc83ba76'),
('67610dc83d97d', 'A', '67610dc83ddeb'),
('67610dc83d97d', 'B', '67610dc83ddee'),
('67610dc83d97d', 'C', '67610dc83ddef'),
('67610dc83d97d', 'D', '67610dc83ddf0'),
('67610ee6b4590', 'A', '67610ee6b4bf9'),
('67610ee6b4590', 'B', '67610ee6b4bfe'),
('67610ee6b4590', 'C', '67610ee6b4bff'),
('67610ee6b4590', 'D', '67610ee6b4c00'),
('67610ee6b60f5', 'A', '67610ee6b6a29'),
('67610ee6b60f5', 'B', '67610ee6b6a31'),
('67610ee6b60f5', 'C', '67610ee6b6a32'),
('67610ee6b60f5', 'D', '67610ee6b6a33'),
('67610ee6b89f6', 'A', '67610ee6b8e55'),
('67610ee6b89f6', 'B', '67610ee6b8e5b'),
('67610ee6b89f6', 'C', '67610ee6b8e5c'),
('67610ee6b89f6', 'D', '67610ee6b8e5d'),
('67610ee6baa3c', 'A', '67610ee6badaf'),
('67610ee6baa3c', 'B', '67610ee6badb2'),
('67610ee6baa3c', 'C', '67610ee6badb3'),
('67610ee6baa3c', 'D', '67610ee6badb4'),
('67610f50bcf02', 'A', '67610f50c6bb8'),
('67610f50bcf02', 'B', '67610f50c6bbe'),
('67610f50bcf02', 'C', '67610f50c6bbf'),
('67610f50bcf02', 'D', '67610f50c6bc0'),
('67610f50c8d4d', 'A', '67610f50c92c6'),
('67610f50c8d4d', 'B', '67610f50c92cd'),
('67610f50c8d4d', 'C', '67610f50c92ce'),
('67610f50c8d4d', 'D', '67610f50c92cf'),
('67610f50cd3c4', 'A', '67610f50ce21b'),
('67610f50cd3c4', 'B', '67610f50ce21f'),
('67610f50cd3c4', 'C', '67610f50ce220'),
('67610f50cd3c4', 'D', '67610f50ce221'),
('67610f50d0845', 'A', '67610f50d12b7'),
('67610f50d0845', 'B', '67610f50d12bc'),
('67610f50d0845', 'C', '67610f50d12bd'),
('67610f50d0845', 'D', '67610f50d12be'),
('67610f50d2b48', 'A', '67610f50d2fef'),
('67610f50d2b48', 'B', '67610f50d2ff2'),
('67610f50d2b48', 'C', '67610f50d2ff3'),
('67610f50d2b48', 'D', '67610f50d2ff4'),
('67610f50d4eff', 'A', '67610f50d5306'),
('67610f50d4eff', 'B', '67610f50d530a'),
('67610f50d4eff', 'C', '67610f50d530b'),
('67610f50d4eff', 'D', '67610f50d530c');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('67610cdfab064', '67610d29ec222', 'question - 1', 4, 1),
('67610cdfab064', '67610d2a044a7', 'question - 2', 4, 2),
('67610cdfab064', '67610d2a05ec6', 'question - 3', 4, 3),
('67610cdfab064', '67610d2a08612', 'question - 4', 4, 4),
('67610cdfab064', '67610d2a0a494', 'question - 5', 4, 5),
('67610d822fc98', '67610dc82c6b5', 'question - 1', 4, 1),
('67610d822fc98', '67610dc837edc', 'question - 2', 4, 2),
('67610d822fc98', '67610dc83a0ef', 'question - 3', 4, 3),
('67610d822fc98', '67610dc83b643', 'question - 4', 4, 4),
('67610d822fc98', '67610dc83d97d', 'question - 5', 4, 5),
('67610eb33fefa', '67610ee6b4590', 'question - 1', 4, 1),
('67610eb33fefa', '67610ee6b60f5', 'question - 2', 4, 2),
('67610eb33fefa', '67610ee6b89f6', 'question - 3', 4, 3),
('67610eb33fefa', '67610ee6baa3c', 'question - 4', 4, 4),
('67610f1aa4f41', '67610f50bcf02', 'question - 1', 4, 1),
('67610f1aa4f41', '67610f50c8d4d', 'question - 2', 4, 2),
('67610f1aa4f41', '67610f50cd3c4', 'question - 3', 4, 3),
('67610f1aa4f41', '67610f50d0845', 'question - 4', 4, 4),
('67610f1aa4f41', '67610f50d2b48', 'question - 5', 4, 5),
('67610f1aa4f41', '67610f50d4eff', 'question - 6', 4, 6);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` varchar(50) NOT NULL,
  `title` varchar(35) NOT NULL,
  `right` int(10) NOT NULL,
  `wrong` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(30) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `email` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `right`, `wrong`, `total`, `time`, `intro`, `tag`, `date`, `email`) VALUES
('67610cdfab064', 'Sample1', 4, 1, 5, 10, '1 To 5 questions....!', 'Sample1', '2024-12-17 05:32:15', 'teacher1@gmail.com'),
('67610d822fc98', 'Sample2', 3, 0, 5, 15, 'question 5 to 10....!', 'Sample2', '2024-12-17 05:34:58', 'teacher1@gmail.com'),
('67610eb33fefa', 'Sample3', 4, 2, 4, 10, 'question 11 to 14....!', 'Sample3', '2024-12-17 05:40:03', 'teacher2@gmail.com'),
('67610f1aa4f41', 'Sample4', 4, 0, 6, 20, 'question 14 to 20...!', 'Sample4', '2024-12-17 05:41:46', 'teacher2@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(30) NOT NULL,
  `score` int(10) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('utsav123@gmail.com', 25, '2024-12-17 06:21:08');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(30) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(35) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mob` bigint(14) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Utsav Saliya', 'M', 'LJMCA', 'utsav123@gmail.com', 9316156136, 'utsav123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
