<?php
include_once 'dbConnection.php';
$ref = @$_GET['q'];
$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

// Insert admin data into the database
$q = mysqli_query($con, "INSERT INTO admin (name, email, password, role) VALUES ('$name', '$email', '$password', 'admin')");

if ($q) {
    // Redirect to dashboard with success message
    header("location:headdash.php?q=6");
} else {
    // Redirect to the same page with an error message
    header("location:$ref?q=Teacher Can not be Registered");
}
